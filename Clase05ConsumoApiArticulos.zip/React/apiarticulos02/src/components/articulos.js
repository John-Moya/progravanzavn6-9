import React from 'react'

const Articulos = ({ articulos }) => {
  return (
    <div>
      <center><h1>Lista de Articulos</h1></center>
      {articulos.map((articulo) => (
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">{articulo.nombre}</h5>
            <h6 class="card-subtitle mb-2 text-muted">{articulo.descripcion}</h6>
            <p class="card-text">{articulo.precio}</p>
          </div>
        </div>
      ))}
    </div>
  )
};

export default Articulos