import React, {Component} from 'react';
import Articulos from './components/articulos';

class App extends Component {
  state = {
    articulos: []
  }

  componentDidMount() {
    fetch('https://localhost:44389/api/Articuloes')
    .then(res => res.json())
    .then((data) => {
      this.setState({ articulos: data })
    })
    .catch(console.log)
  }

  render() {
    return (
      <Articulos articulos={this.state.articulos} />
    )
  }
}

export default App;
