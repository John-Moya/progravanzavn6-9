﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Clase5ApiArticulo.Modelo;

namespace Clase5ApiArticulo.Data
{
    public class Clase5ApiArticuloContext : DbContext
    {
        public Clase5ApiArticuloContext (DbContextOptions<Clase5ApiArticuloContext> options)
            : base(options)
        {
        }

        public DbSet<Clase5ApiArticulo.Modelo.Articulo> Articulo { get; set; }
    }
}
