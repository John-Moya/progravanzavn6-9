﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Clase3Tienda_YamillMoran.Models;

namespace Clase3Tienda_YamillMoran.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Clase3Tienda_YamillMoran.Models.Pedido> Pedido { get; set; }
    }
}
