﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Clase3Tienda_YamillMoran.Models
{
    public class Pedido
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Direccion { get; set; }
        public int Numero { get; set; }
        public string Articulo { get; set; }
        public int Cantidad { get; set; }
    }
}
