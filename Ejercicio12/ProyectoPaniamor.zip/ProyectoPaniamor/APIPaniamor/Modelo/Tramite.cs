﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIPaniamor
{
    public class Tramite
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int Cedula { get; set; }
        public string Fecha { get; set; }
        public string TipoDeTramite { get; set; }
    }
}
