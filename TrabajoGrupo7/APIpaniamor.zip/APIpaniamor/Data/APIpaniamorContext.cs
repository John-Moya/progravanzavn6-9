﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using APIpaniamor.Models;

namespace APIpaniamor.Data
{
    public class APIpaniamorContext : DbContext
    {
        public APIpaniamorContext (DbContextOptions<APIpaniamorContext> options)
            : base(options)
        {
        }

        public DbSet<APIpaniamor.Models.Tramite> Tramite { get; set; }
    }
}
